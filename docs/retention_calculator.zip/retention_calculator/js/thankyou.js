var link = document.getElementById("back");
link.setAttribute("href", "/" + location.search);